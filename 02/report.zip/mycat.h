#ifndef __MYCAT_H__
#define __MYCAT_H__

int do_cat(int size, char **args);

#endif
